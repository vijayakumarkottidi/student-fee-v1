<?php
header('Content-Type: text/html; charset=utf-8');
/**
 * Student Dashboard - Hiticx
 */

// Simple error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Correct WordPress path for your server
$wp_load_path = '/home/hitiypom/public_html/wp-load.php';

if (file_exists($wp_load_path)) {
    require_once($wp_load_path);
} else {
    die('
    <div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
        <h1>🚧 Configuration Error</h1>
        <p>WordPress not found at: ' . $wp_load_path . '</p>
        <p>Please contact the administrator.</p>
    </div>
    ');
}

// Check if student is logged in
if (!session_id()) {
    session_start();
}

if (!isset($_SESSION['sfm_student_id'])) {
    header('Location: portal-login.php');
    exit;
}

$student_id = $_SESSION['sfm_student_id'];

// Get student data
global $wpdb;
$students_table = $wpdb->prefix . 'sfm_pro_students';
$installments_table = $wpdb->prefix . 'sfm_pro_installments';

$student = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM $students_table WHERE id = %d", 
    $student_id
));

if (!$student) {
    session_destroy();
    header('Location: portal-login.php');
    exit;
}

// Get installments
$installments = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM $installments_table WHERE student_id = %d ORDER BY installment_no ASC", 
    $student_id
));

// Calculate totals
$total_paid = floatval($student->upfront_payment);
$installments_paid = 0;
$overdue_count = 0;

foreach ($installments as $installment) {
    $installments_paid += floatval($installment->paid);
    $total_paid += floatval($installment->paid);
    
    // Check if overdue
    if ($installment->paid < $installment->amount && strtotime($installment->due_date) < time()) {
        $overdue_count++;
    }
}

$remaining_balance = max(0, $student->course_fee - $total_paid);

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: portal-login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - <?php echo $student->student_name; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .header {
            background: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .student-info h1 {
            margin-bottom: 5px;
            color: #333;
        }
        
        .student-info p {
            color: #666;
        }
        
        .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: #c0392b;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .metric-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .metric-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .metric-value {
            font-size: 28px;
            font-weight: bold;
            color: #0073aa;
        }
        
        .metric-card.overdue .metric-value {
            color: #e74c3c;
        }
        
        .info-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .info-section h2 {
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #0073aa;
            padding-bottom: 10px;
        }
        
        .installments-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .installments-table th,
        .installments-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .installments-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .status-paid {
            color: #27ae60;
            font-weight: bold;
        }
        
        .status-pending {
            color: #f39c12;
            font-weight: bold;
        }
        
        .status-overdue {
            color: #e74c3c;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .metrics-grid {
                grid-template-columns: 1fr;
            }
            
            .header-content {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .installments-table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="student-info">
                <h1>Welcome, <?php echo $student->student_name; ?>! 👋</h1>
                <p>Student ID: <?php echo $student->student_code; ?> | Course: <?php echo $student->course_name; ?></p>
            </div>
            <a href="?logout=1" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="metrics-grid">
            <div class="metric-card">
                <h3>Total Course Fee</h3>
                <div class="metric-value">£<?php echo number_format($student->course_fee, 2); ?></div>
            </div>
            <div class="metric-card">
                <h3>Upfront Paid</h3>
                <div class="metric-value">£<?php echo number_format($student->upfront_payment, 2); ?></div>
            </div>
            <div class="metric-card">
                <h3>Installments Paid</h3>
                <div class="metric-value">£<?php echo number_format($installments_paid, 2); ?></div>
            </div>
            <div class="metric-card">
                <h3>Remaining Balance</h3>
                <div class="metric-value">£<?php echo number_format($remaining_balance, 2); ?></div>
            </div>
            <div class="metric-card <?php echo $overdue_count > 0 ? 'overdue' : ''; ?>">
                <h3>Overdue Payments</h3>
                <div class="metric-value"><?php echo $overdue_count; ?></div>
            </div>
        </div>

        <div class="info-section">
            <h2>📚 Course Information</h2>
            <p><strong>Course Name:</strong> <?php echo $student->course_name; ?></p>
            <p><strong>Join Date:</strong> <?php echo date('F j, Y', strtotime($student->join_date)); ?></p>
            <p><strong>Next Payment Date:</strong> <?php echo date('F j, Y', strtotime($student->next_payment_date)); ?></p>
            <p><strong>Total Paid:</strong> £<?php echo number_format($total_paid, 2); ?> (£<?php echo number_format($student->upfront_payment, 2); ?> upfront + £<?php echo number_format($installments_paid, 2); ?> installments)</p>
            <p><strong>Status:</strong> <span class="status-<?php echo strtolower($student->status); ?>"><?php echo $student->status; ?></span></p>
        </div>

        <div class="info-section">
            <h2>💰 Payment Schedule</h2>
            <?php if (!empty($installments)): ?>
                <table class="installments-table">
                    <thead>
                        <tr>
                            <th>Installment</th>
                            <th>Due Date</th>
                            <th>Amount</th>
                            <th>Paid</th>
                            <th>Remaining</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($installments as $installment): 
                            $remaining = $installment->amount - $installment->paid;
                            $due_date = strtotime($installment->due_date);
                            $today = time();
                            
                            if ($installment->paid >= $installment->amount) {
                                $status = 'Paid';
                                $status_class = 'status-paid';
                            } elseif ($due_date < $today && $installment->paid < $installment->amount) {
                                $status = 'Overdue';
                                $status_class = 'status-overdue';
                            } else {
                                $status = 'Pending';
                                $status_class = 'status-pending';
                            }
                        ?>
                        <tr>
                            <td>#<?php echo $installment->installment_no; ?></td>
                            <td><?php echo date('M j, Y', $due_date); ?></td>
                            <td>£<?php echo number_format($installment->amount, 2); ?></td>
                            <td>£<?php echo number_format($installment->paid, 2); ?></td>
                            <td>£<?php echo number_format($remaining, 2); ?></td>
                            <td class="<?php echo $status_class; ?>">
                                <?php echo $status; ?>
                                <?php if ($installment->paid > 0): ?>
                                    <br>
                                    <div style="margin-top: 5px;">
                                        <a href="download-receipt.php?installment_id=<?php echo $installment->id; ?>" 
                                           target="_blank" 
                                           style="color: #0073aa; font-size: 11px; text-decoration: none; background: #eef7ff; padding: 2px 6px; border-radius: 3px; border: 1px solid #0073aa; display: inline-block; margin-right: 5px;">
                                           📄 Receipt
                                        </a>
                                        <a href="download-receipt.php?installment_id=<?php echo $installment->id; ?>&print=1" 
                                           target="_blank" 
                                           style="color: #27ae60; font-size: 11px; text-decoration: none; background: #e6f4ea; padding: 2px 6px; border-radius: 3px; border: 1px solid #27ae60; display: inline-block;">
                                           🖨️ Print
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No installments scheduled.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>