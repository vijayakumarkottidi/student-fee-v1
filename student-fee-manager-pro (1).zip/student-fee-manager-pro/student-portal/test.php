<?php
echo "<h1>Student Portal Test</h1>";
echo "<p>If you can see this, the PHP is working!</p>";
echo "<p>Server Time: " . date('Y-m-d H:i:s') . "</p>";

// Test basic functionality
echo "<h2>Basic Tests:</h2>";
echo "<p>1. PHP Version: " . phpversion() . " ✅</p>";
echo "<p>2. File loaded successfully ✅</p>";

// Test WordPress connection
echo "<h2>WordPress Connection Test:</h2>";
try {
    define('ABSPATH', dirname(dirname(dirname(dirname(__FILE__)))) . '/');
    
    if (file_exists(ABSPATH . 'wp-load.php')) {
        require_once(ABSPATH . 'wp-load.php');
        echo "<p>3. WordPress loaded successfully ✅</p>";
        
        // Test database connection
        global $wpdb;
        if ($wpdb) {
            echo "<p>4. Database connection successful ✅</p>";
        } else {
            echo "<p>4. Database connection failed ❌</p>";
        }
    } else {
        echo "<p>3. WordPress not found at: " . ABSPATH . "wp-load.php ❌</p>";
    }
} catch (Exception $e) {
    echo "<p>3. Error loading WordPress: " . $e->getMessage() . " ❌</p>";
}
?>