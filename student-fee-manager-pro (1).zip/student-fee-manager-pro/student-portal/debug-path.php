<?php
/**
 * Debug WordPress Path Finder
 */

echo "<h1>WordPress Path Debugger</h1>";

// Show current file location
echo "<p><strong>Current file:</strong> " . __FILE__ . "</p>";
echo "<p><strong>Current directory:</strong> " . __DIR__ . "</p>";

// Try to find wp-load.php
$search_paths = [
    __DIR__ . '/wp-load.php',
    dirname(__DIR__) . '/wp-load.php',
    dirname(dirname(__DIR__)) . '/wp-load.php',
    dirname(dirname(dirname(__DIR__))) . '/wp-load.php',
    dirname(dirname(dirname(dirname(__DIR__)))) . '/wp-load.php',
    '/home/hitiypom/public_html/wp-load.php',
    $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php'
];

echo "<h2>Searching for wp-load.php:</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Path</th><th>Exists</th></tr>";

foreach ($search_paths as $path) {
    $exists = file_exists($path) ? '✅ YES' : '❌ NO';
    echo "<tr><td>$path</td><td>$exists</td></tr>";
    
    if (file_exists($path)) {
        echo "<tr><td colspan='2' style='background:lightgreen;'><strong>FOUND WORDPRESS:</strong> $path</td></tr>";
        
        // Test loading WordPress
        echo "<tr><td colspan='2'>";
        try {
            require_once($path);
            if (function_exists('get_bloginfo')) {
                echo "✅ WordPress loaded successfully!<br>";
                echo "Site: " . get_bloginfo('name') . "<br>";
                echo "URL: " . get_bloginfo('url');
            } else {
                echo "❌ WordPress file loaded but functions not available";
            }
        } catch (Exception $e) {
            echo "❌ Error loading: " . $e->getMessage();
        }
        echo "</td></tr>";
        break;
    }
}
echo "</table>";

// Show server information
echo "<h2>Server Information:</h2>";
echo "<p><strong>Document Root:</strong> " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Not set') . "</p>";
echo "<p><strong>PHP Self:</strong> " . ($_SERVER['PHP_SELF'] ?? 'Not set') . "</p>";

// Directory tree
echo "<h2>Directory Structure:</h2>";
function show_dir_tree($dir, $depth = 0) {
    if ($depth > 3) return; // Limit depth
    $items = scandir($dir);
    echo "<ul>";
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        $is_dir = is_dir($path);
        echo "<li>";
        echo $is_dir ? "📁 " : "📄 ";
        echo $item;
        if ($is_dir && $depth < 2) {
            show_dir_tree($path, $depth + 1);
        }
        echo "</li>";
    }
    echo "</ul>";
}

echo "<p>From current directory:</p>";
show_dir_tree(__DIR__);
?>