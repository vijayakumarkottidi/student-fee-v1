<?php
// Try the most likely path directly
$wp_path = '/home/hitiypom/public_html/wp-load.php';
echo "<h1>Testing: $wp_path</h1>";

if (file_exists($wp_path)) {
    require_once($wp_path);
    echo "✅ WordPress found and loaded!<br>";
    echo "Site: " . get_bloginfo('name');
} else {
    echo "❌ WordPress not found at: $wp_path";
    
    // Show what's in public_html
    echo "<h2>Contents of public_html:</h2>";
    $public_html = '/home/hitiypom/public_html/';
    if (is_dir($public_html)) {
        $files = scandir($public_html);
        echo "<pre>";
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                echo $file . "\n";
            }
        }
        echo "</pre>";
    } else {
        echo "public_html directory not found!";
    }
}
?>